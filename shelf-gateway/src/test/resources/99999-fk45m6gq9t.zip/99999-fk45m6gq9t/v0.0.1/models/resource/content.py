from math import exp
import math

def getIschemicRisk(riskValues):

	DAPTkey = 'DAPT'
	infarKey = 'infar'
	priorPCIkey = 'priorPCI'
	CHFhistKey = 'CHF'
	veinGraftKey = 'veinGraft'
	stentDiameterKey = 'stentDiameter'
	pacKey = 'pac'
	cigKey = 'cigSmoker'
	diabetesKey = 'diabetes'
	periphKey = 'periphDisease'
	hypertensionKey = 'hypertension'
	renalKey = 'renal'

	keys = [DAPTkey, infarKey, priorPCIkey, CHFhistKey, veinGraftKey, stentDiameterKey, 
			pacKey, cigKey, diabetesKey, periphKey, hypertensionKey, renalKey]

	#Cox regression coefficients
	regressions = {DAPTkey: -0.653, infarKey: 0.499, priorPCIkey: 0.58, CHFhistKey: 0.633, veinGraftKey: 0.562, 
					stentDiameterKey: 0.475, pacKey: 0.454, cigKey: 0.333, diabetesKey: 0.320, periphKey: 0.401,
					 hypertensionKey: 0.315, renalKey: 0.435}

	#Kaplan-Meier base rate of freedom
	S18 = 0.9691 
	#this sum is estimated from the DAPT study
	meanCoefficientSum = 0.79

	individualCoefficientSum = 0
	
	#summation
	for key in keys:
		#print 'riskvalues[{}]: {}'.format(i, riskValues[i])
		#print 'doing {} + {}'.format(individualCoefficientSum, riskValues[i] * regressions[i])
		individualCoefficientSum = individualCoefficientSum + (riskValues[key] * regressions[key])

	#print 'indivco: {}'.format(individualCoefficientSum)



	exponent = exp(individualCoefficientSum - meanCoefficientSum)
	#print 'exponent: {}'.format(exponent)

	return float(1 - pow(S18, exponent))


def test_function():

	DAPTkey = 'DAPT'
	infarKey = 'infar'
	priorPCIkey = 'priorPCI'
	CHFhistKey = 'CHF'
	veinGraftKey = 'veinGraft'
	stentDiameterKey = 'stentDiameter'
	pacKey = 'pac'
	cigKey = 'cigSmoker'
	diabetesKey = 'diabetes'
	periphKey = 'periphDisease'
	hypertensionKey = 'hypertension'
	renalKey = 'renal'

	test_inputs = [
						{'DAPT': 1, 'infar': 0, 'priorPCI': 0, 'CHF': 0, 'veinGraft': 0, 'stentDiameter': 1, 'pac': 1, 'cigSmoker': 1,
						'diabetes': 0, 'periphDisease': 0, 'hypertension': 1, 'renal': 0},

						{'DAPT': 0, 'infar': 0, 'priorPCI': 0, 'CHF': 0, 'veinGraft': 0, 'stentDiameter': 0, 'pac': 0, 'cigSmoker': 0,
						'diabetes': 0, 'periphDisease': 0, 'hypertension': 0, 'renal': 0},

						{'DAPT': 1, 'infar': 1, 'priorPCI': 1, 'CHF': 1, 'veinGraft': 1, 'stentDiameter': 1, 'pac': 1, 'cigSmoker': 1,
						'diabetes': 1, 'periphDisease': 1, 'hypertension': 1, 'renal': 1},

						{'DAPT': 1, 'infar': 1, 'priorPCI': 1, 'CHF': 1, 'veinGraft': 1, 'stentDiameter': 1, 'pac': 0, 'cigSmoker': 0,
						'diabetes': 0, 'periphDisease': 0, 'hypertension': 0, 'renal': 0},

						{'DAPT': 1, 'infar': 0, 'priorPCI': 0, 'CHF': 0, 'veinGraft': 0, 'stentDiameter': 0, 'pac': 0, 'cigSmoker': 0,
						'diabetes': 0, 'periphDisease': 0, 'hypertension': 0, 'renal': 0}
				   ]

	correctOutputs =	[0.035251864828, 0.01414406, 0.66982, 0.1094, 0.00739]
	correctOutputIndex = 0

	for test_in in test_inputs:
		result = getIschemicRisk(test_in)
		print 'result: {}'.format(result)
		print 'correct: {}'.format(correctOutputs[correctOutputIndex])
		assert (result > (correctOutputs[correctOutputIndex]- 0.001) and result < (correctOutputs[correctOutputIndex] + 0.001))
		correctOutputIndex += 1

