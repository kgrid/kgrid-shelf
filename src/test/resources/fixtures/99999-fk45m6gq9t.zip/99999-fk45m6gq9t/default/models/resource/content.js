function content(riskValues) {
	return riskValues
}
